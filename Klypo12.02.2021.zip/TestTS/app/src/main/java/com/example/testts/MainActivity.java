package com.example.testts;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SMainActivity extends AppCompatActivity {

    private EditText name, surname, third_name, age;
    private Button bin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.editTextName);
        surname = findViewById(R.id.editTextSurName);
        third_name = findViewById(R.id.editTextThird_Name);
        age = findViewById(R.id.editTextClass);
        bin = findViewById(R.id.button);

        bin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toSecondScreen = new Intent(MainActivity.this, SecondScreen.class);
                startActivity(toSecondScreen);
            }
        });


    }
}