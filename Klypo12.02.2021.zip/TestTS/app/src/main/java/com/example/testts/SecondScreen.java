package com.example.testts;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class SecondScreen extends AppCompatActivity {

    private CheckBox check1, check2, check3, check4;
    private Button button;
    int points = 0, quantity = 0;
    static protected double result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);

        check1 = findViewById(R.id.checkBox);
        check2 = findViewById(R.id.checkBox2);
        check3 = findViewById(R.id.checkBox3);
        check4 = findViewById(R.id.checkBox4);
        button = findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (check1.isChecked()) {
                    points += 2;
                    quantity++;
                }
                if (check2.isChecked()) {
                    points += 5;
                    quantity++;
                }
                if (check3.isChecked()) {
                points += 4;
                quantity++;
            }
                if (check4.isChecked()){
                    points += 3;
                    quantity++;
                }
                result = points / quantity;
                Intent toThirdScreen = new Intent(SecondScreen.this, ThirdScreen.class);
                startActivity(toThirdScreen);
            }

        }
        });
    }
}