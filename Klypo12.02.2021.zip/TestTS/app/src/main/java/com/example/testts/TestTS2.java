package com.example.testts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SecondScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_t_s2);
    }
}