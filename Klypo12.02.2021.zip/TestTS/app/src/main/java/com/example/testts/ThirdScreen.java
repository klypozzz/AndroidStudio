package com.example.testts;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class ThirdScreen extends AppCompatActivity {

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_screen2);

        button = findViewById(R.id.button4);

        setContentView(R.layout.activity_second_screen);
        TextView textView = (TextView) findViewById(R.id.textView4);
        textView.setText(MainActivity.name + " " + MainActivity.surname + " " + MainActivity.third_name + " " + SecondScreen.result);

    }
}